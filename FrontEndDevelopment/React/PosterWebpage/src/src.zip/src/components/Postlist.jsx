// const names = ["Nirmal", "Raj"];
// import { useState, useEffect } from "react";
// import Modal from "./Modal";
// import NewPost from "../routes/NewPost";
import classes from "./Postlist.module.css";
// import classes from './Post.module.css';
import Post from "./post";
import { useLoaderData } from "react-router-dom";
function Postlist() {
  // isPosting = false;
  const posts = useLoaderData();

  // const [modalIsVisible, setModalIsVisible] = useState(true);

  return (
    <>
      {posts.length > 0 && (
        <ul className={classes.posts}>
          {/* <Post author={enteredAuthor} body={enteredBody} /> */}
          {/* <Post author="He will work harder" body="and get better!!!" /> */}
          {posts.map((post) => (
            <Post key={post.id} id={post.id} author={post.author} body={post.body} />
          ))}
        </ul>
      )}
      {posts.length === 0 && (
        <div style={{ textAlight: "center", color: "white" }}>
          <h2>There is no post yet.</h2>
          <p>Goahead and add your poster!!!</p>
        </div>
      )}
    </>
  );
}

export default Postlist;
