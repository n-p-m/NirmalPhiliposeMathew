import Post from "../components/post";
import Postlist from "../components/Postlist";
// import MainHeader from "../components/MainHeader";
import { useState } from "react";
import { Outlet } from "react-router-dom";
function Posts() {
  // once we defined the component, we just need to
  // use that component as a html tag
  // const [modalIsVisible, setModalIsVisible] = useState(false);

  // function hideModalHandler() {
  //   setModalIsVisible(false);
  // }
  // function showModalHandler() {
  //   setModalIsVisible(true);
  // }

  return (
    <>
      {/* <MainHeader onCreatePost={showModalHandler} /> */}
      <Outlet />
      <main>
        <Postlist />
      </main>
    </>
  );
}

export default Posts;

export async function loader() {
  const response = await fetch("http://localhost:8080/posts");
  const resData = await response.json();
  return resData.posts;
}


